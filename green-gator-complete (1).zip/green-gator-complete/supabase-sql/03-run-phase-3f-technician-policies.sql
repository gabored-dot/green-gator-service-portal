-- GREEN GATOR — PHASE 3F: technician access (REVIEW BEFORE RUNNING; not executed by Claude)
-- Based ONLY on the verified relationship:
--   appointments.assigned_technician_id -> technicians.id ; technicians.profile_id -> profiles.id
-- Policy/function names are unique, so re-running is safe. Your existing customer/admin policies are not touched.
-- Roles are read from profiles.role ('customer','technician','admin','executive').

-- 1) Helpers (SECURITY DEFINER so policies never recurse through RLS)
create or replace function public.is_assigned_technician(tech_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.technicians t where t.id = tech_id and t.profile_id = auth.uid());
$$;

create or replace function public.technician_serves_customer(cust_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.appointments a
                 where a.customer_id = cust_id and public.is_assigned_technician(a.assigned_technician_id));
$$;

-- 2) A technician can read their own technician row
drop policy if exists tech_select_own_row on public.technicians;
create policy tech_select_own_row on public.technicians for select to authenticated
  using (profile_id = auth.uid());

-- 3) A technician can read ONLY appointments assigned to them
drop policy if exists tech_select_assigned_appointments on public.appointments;
create policy tech_select_assigned_appointments on public.appointments for select to authenticated
  using (public.is_assigned_technician(assigned_technician_id));

-- 4) A technician can move ONLY their own jobs forward, and never to 'completed' (that belongs to the Phase 3G completion process)
drop policy if exists tech_update_assigned_appointments on public.appointments;
create policy tech_update_assigned_appointments on public.appointments for update to authenticated
  using (public.is_assigned_technician(assigned_technician_id) and status in ('confirmed','assigned','en_route'))
  with check (public.is_assigned_technician(assigned_technician_id) and status in ('en_route','in_progress'));

-- 5) A technician may change nothing except the status (and timestamps) of an appointment
create or replace function public.guard_technician_appointment_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;                                   -- internal/server contexts
  if exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin','executive')) then return new; end if;
  if public.is_assigned_technician(old.assigned_technician_id) then
    if (to_jsonb(new) - 'status' - 'updated_at' - 'started_at' - 'completed_at')
       is distinct from (to_jsonb(old) - 'status' - 'updated_at' - 'started_at' - 'completed_at') then
      raise exception 'Technicians may only change the job status';
    end if;
    if new.status = 'completed' then
      raise exception 'Jobs are completed through the completion process';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_technician_appointment_update on public.appointments;
create trigger trg_guard_technician_appointment_update before update on public.appointments
  for each row execute function public.guard_technician_appointment_update();

-- 6) A technician can read the customer (and profile) of appointments assigned to them, nothing else
drop policy if exists tech_select_served_customers on public.customers;
create policy tech_select_served_customers on public.customers for select to authenticated
  using (public.technician_serves_customer(id));

create or replace function public.technician_serves_profile(pid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.customers c where c.profile_id = pid and public.technician_serves_customer(c.id));
$$;
drop policy if exists tech_select_served_profiles on public.profiles;
create policy tech_select_served_profiles on public.profiles for select to authenticated
  using (public.technician_serves_profile(id));

-- NOTE: emergency_requests ownership column was not verified. If it is assigned_technician_id (-> technicians.id), add the same
-- pattern (select + status-only update) for it; send me the column list and I will write it.
