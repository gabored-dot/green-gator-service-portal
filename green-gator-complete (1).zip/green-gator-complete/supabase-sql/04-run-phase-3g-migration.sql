-- GREEN GATOR — PHASE 3G: PROPOSED MIGRATION (REVIEW FIRST; NOT EXECUTED BY CLAUDE).
-- Run phase-3g-inspect.sql first and send me the result; adjust anything this file assumes.
-- Verified: appointments.assigned_technician_id -> technicians.id ; technicians.profile_id -> profiles.id ;
--           job_media(id, job_id, technician_id, media_type, storage_path, file_name, mime_type, file_size, caption, created_at).
-- job_notes and job_signatures are created in step 0 if they do not exist yet.
--           job_id holds either an appointments.id or a service_jobs.id (service_jobs.appointment_id links back).
-- Idempotent: functions use CREATE OR REPLACE; policies/triggers use unique names with DROP IF EXISTS. No data is deleted. The bucket stays private.

-- 0) FIX: your inspection showed that public.job_notes does NOT exist (and job_signatures was never in your schema list).
--    Both are created here ONLY IF MISSING, with exactly the columns the portal writes. Nothing existing is altered or deleted.
--    job_id has no foreign key on purpose: the portal stores the service_jobs id when a job record exists, otherwise the appointment id.
create table if not exists public.job_notes (
  id            uuid primary key default gen_random_uuid(),
  job_id        uuid not null,
  technician_id uuid references public.technicians(id),
  author_id     uuid,
  content       text not null check (char_length(content) between 1 and 1000),
  created_at    timestamptz not null default now()
);
create index if not exists job_notes_job_id_idx on public.job_notes (job_id, created_at);

create table if not exists public.job_signatures (
  id            uuid primary key default gen_random_uuid(),
  job_id        uuid not null,
  technician_id uuid references public.technicians(id),
  storage_path  text not null,
  signer_name   text,
  mime_type     text default 'image/png',
  created_at    timestamptz not null default now()
);
create unique index if not exists job_signatures_job_id_uidx on public.job_signatures (job_id);     -- one signature per job

-- Table privileges (row access is still decided by the RLS policies below; anon gets nothing, nobody can delete).
grant select, insert on public.job_notes to authenticated;
grant select, insert, update on public.job_signatures to authenticated;
revoke all on public.job_notes, public.job_signatures from anon;

-- 1) Helpers (SECURITY DEFINER so policies never recurse through RLS) ---------------------------------------------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

create or replace function public.is_assigned_technician(tech_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.technicians t where t.id = tech_id and t.profile_id = auth.uid());
$$;

-- every id a job may be stored under: the appointment id itself, plus its service_jobs ids (if that table/column exists)
create or replace function public.job_ids_for_appointment(appt uuid) returns setof uuid
language plpgsql stable security definer set search_path = public as $$
begin
  return next appt;
  begin
    return query execute 'select id from public.service_jobs where appointment_id = $1' using appt;
  exception when undefined_table or undefined_column then null;
  end;
end $$;

create or replace function public.job_appointment_ids(job uuid) returns setof uuid
language plpgsql stable security definer set search_path = public as $$
begin
  return query select a.id from public.appointments a where a.id = job;
  begin
    return query execute 'select appointment_id from public.service_jobs where id = $1' using job;
  exception when undefined_table or undefined_column then null;
  end;
end $$;

-- can the signed-in user read (or write) things stored under this job id? Writes only while the job is still open.
create or replace function public.tech_can_access_job(job uuid, for_write boolean) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin() or exists (
    select 1 from public.appointments a
    where a.id in (select public.job_appointment_ids(job))
      and public.is_assigned_technician(a.assigned_technician_id)
      and (not for_write or a.status in ('confirmed','assigned','en_route','in_progress')));
$$;

create or replace function public.job_folder_access(folder text, for_write boolean) returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
  if folder is null or folder !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return false; end if;
  return public.tech_can_access_job(folder::uuid, for_write);
end $$;

-- 2) Table policies (RLS stays ON; customers get no access to these tables) ----------------------------------------
alter table public.job_media      enable row level security;
alter table public.job_notes      enable row level security;
alter table public.job_signatures enable row level security;

drop policy if exists p3g_media_select on public.job_media;
create policy p3g_media_select on public.job_media for select to authenticated using (public.tech_can_access_job(job_id, false));
drop policy if exists p3g_media_insert on public.job_media;
create policy p3g_media_insert on public.job_media for insert to authenticated
  with check (public.tech_can_access_job(job_id, true) and (public.is_admin() or public.is_assigned_technician(technician_id)));
drop policy if exists p3g_media_delete on public.job_media;
create policy p3g_media_delete on public.job_media for delete to authenticated using (public.tech_can_access_job(job_id, true));

drop policy if exists p3g_notes_select on public.job_notes;
create policy p3g_notes_select on public.job_notes for select to authenticated using (public.tech_can_access_job(job_id, false));
drop policy if exists p3g_notes_insert on public.job_notes;
create policy p3g_notes_insert on public.job_notes for insert to authenticated
  with check (public.tech_can_access_job(job_id, true) and (public.is_admin() or technician_id is null or public.is_assigned_technician(technician_id)));

drop policy if exists p3g_sig_select on public.job_signatures;
create policy p3g_sig_select on public.job_signatures for select to authenticated using (public.tech_can_access_job(job_id, false));
drop policy if exists p3g_sig_insert on public.job_signatures;
create policy p3g_sig_insert on public.job_signatures for insert to authenticated
  with check (public.tech_can_access_job(job_id, true) and (public.is_admin() or technician_id is null or public.is_assigned_technician(technician_id)));
drop policy if exists p3g_sig_update on public.job_signatures;
create policy p3g_sig_update on public.job_signatures for update to authenticated
  using (public.tech_can_access_job(job_id, true)) with check (public.tech_can_access_job(job_id, true));

-- 3) Storage policies for the EXISTING private bucket 'job-media': the first folder of the object path is the job id ----
drop policy if exists p3g_storage_select on storage.objects;
create policy p3g_storage_select on storage.objects for select to authenticated
  using (bucket_id = 'job-media' and public.job_folder_access((storage.foldername(name))[1], false));
drop policy if exists p3g_storage_insert on storage.objects;
create policy p3g_storage_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'job-media' and public.job_folder_access((storage.foldername(name))[1], true));
drop policy if exists p3g_storage_delete on storage.objects;
create policy p3g_storage_delete on storage.objects for delete to authenticated
  using (bucket_id = 'job-media' and public.job_folder_access((storage.foldername(name))[1], true));

-- 4) Completion: the ONLY way a technician can set 'completed' --------------------------------------------------------
create or replace function public.complete_job_for_appointment(p_appointment_id uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a public.appointments%rowtype; v_ids uuid[]; v_notes int; v_sigs int;
begin
  select * into a from public.appointments where id = p_appointment_id for update;
  if not found then raise exception 'job_not_found'; end if;
  if not (public.is_admin() or public.is_assigned_technician(a.assigned_technician_id)) then raise exception 'not_authorized'; end if;
  if a.status <> 'in_progress' then raise exception 'invalid_status'; end if;
  select array_agg(x) into v_ids from public.job_ids_for_appointment(p_appointment_id) x;
  select count(*) into v_notes from public.job_notes where job_id = any(v_ids);
  select count(*) into v_sigs  from public.job_signatures where job_id = any(v_ids);
  if v_notes < 1 then raise exception 'notes_required'; end if;
  if v_sigs  < 1 then raise exception 'signature_required'; end if;
  perform set_config('app.completing', 'on', true);                       -- lets the guard trigger below allow this one update
  update public.appointments set status = 'completed' where id = p_appointment_id;
  begin execute 'update public.appointments set completed_at = now() where id = $1' using p_appointment_id;
  exception when undefined_column then null; end;
  begin execute 'update public.service_jobs set status = ''completed'' where appointment_id = $1' using p_appointment_id;
  exception when undefined_table or undefined_column or invalid_text_representation then null; end;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.complete_job_for_appointment(uuid) from public, anon;
grant execute on function public.complete_job_for_appointment(uuid) to authenticated;

-- 5) Update the Phase 3F guard so technicians still cannot set 'completed' directly, but the function above can ---------
create or replace function public.guard_technician_appointment_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;
  if current_setting('app.completing', true) = 'on' then return new; end if;          -- set only inside complete_job_for_appointment
  if public.is_admin() or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'executive') then return new; end if;
  if public.is_assigned_technician(old.assigned_technician_id) then
    if (to_jsonb(new) - 'status' - 'updated_at' - 'started_at' - 'completed_at') is distinct from (to_jsonb(old) - 'status' - 'updated_at' - 'started_at' - 'completed_at') then
      raise exception 'Technicians may only change the job status';
    end if;
    if new.status = 'completed' then raise exception 'Jobs are completed through the completion process'; end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_technician_appointment_update on public.appointments;
create trigger trg_guard_technician_appointment_update before update on public.appointments
  for each row execute function public.guard_technician_appointment_update();

-- Not changed here: the bucket's privacy/allowed types, any existing complete_job function, customer policies, emergency_requests.
