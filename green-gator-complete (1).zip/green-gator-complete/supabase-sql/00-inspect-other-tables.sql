-- READ-ONLY. Changes nothing. Run in the Supabase SQL Editor and send me the result.
-- Lists the columns of tables I have not seen yet.
select table_name, column_name, data_type, is_nullable
from information_schema.columns
where table_schema = 'public'
  and table_name in ('emergency_requests','emergency_media','callback_requests','service_reports','services','technicians','customers','business_settings')
order by table_name, ordinal_position;
