-- GREEN GATOR — ADMIN SCHEDULING (PROPOSED; REVIEW BEFORE RUNNING; NOT RUN BY CLAUDE)
-- Needed for the admin Appointments page, the Calendar and technician assignment to work on live data.
-- Verified columns used: appointments(id, customer_id, assigned_technician_id, appointment_date, start_time, end_time, status).
-- Roles come from profiles.role. Admin may read AND edit; executive (owner) may only READ. Customers/technicians are unaffected.
-- Safe to re-run (unique policy names, CREATE OR REPLACE). Deletes nothing. Run AFTER 03, 04 and 05.
-- Executive access is deliberately limited to appointments, customers, technicians, profiles, emergency and callback requests:
-- NOT job notes, photos, signatures or audit-protected data beyond what policies in 04/05 already allow.

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'); $$;
create or replace function public.is_executive() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'executive'); $$;

-- 1) Read access for the business (admin + executive)
drop policy if exists p3k_staff_select_appointments on public.appointments;
create policy p3k_staff_select_appointments on public.appointments for select to authenticated using (public.is_admin() or public.is_executive());
drop policy if exists p3k_staff_select_customers on public.customers;
create policy p3k_staff_select_customers on public.customers for select to authenticated using (public.is_admin() or public.is_executive());
drop policy if exists p3k_staff_select_technicians on public.technicians;
create policy p3k_staff_select_technicians on public.technicians for select to authenticated using (public.is_admin() or public.is_executive());
drop policy if exists p3k_staff_select_profiles on public.profiles;
create policy p3k_staff_select_profiles on public.profiles for select to authenticated using (public.is_admin() or public.is_executive());
drop policy if exists p3k_staff_select_emergency on public.emergency_requests;
create policy p3k_staff_select_emergency on public.emergency_requests for select to authenticated using (public.is_admin() or public.is_executive());
drop policy if exists p3k_staff_select_callbacks on public.callback_requests;
create policy p3k_staff_select_callbacks on public.callback_requests for select to authenticated using (public.is_admin() or public.is_executive());

-- 2) Write access: ADMIN only (executive stays read-only unless you decide otherwise)
drop policy if exists p3k_admin_update_appointments on public.appointments;
create policy p3k_admin_update_appointments on public.appointments for update to authenticated using (public.is_admin()) with check (public.is_admin());
-- To let the owner edit too, replace is_admin() above with (public.is_admin() or public.is_executive()) AND set executiveCanEdit: true in js/config.js.

-- 3) A technician can never be double-booked, no matter which screen or API makes the change
create or replace function public.p3k_prevent_technician_overlap() returns trigger
language plpgsql security definer set search_path = public as $$
declare active text[] := array['requested','confirmed','assigned','en_route','in_progress']; n_end time;
begin
  if new.assigned_technician_id is null or new.appointment_date is null or new.start_time is null then return new; end if;
  if not (new.status::text = any(active)) then return new; end if;
  if tg_op = 'UPDATE' and new.assigned_technician_id is not distinct from old.assigned_technician_id and new.appointment_date is not distinct from old.appointment_date
     and new.start_time is not distinct from old.start_time and new.end_time is not distinct from old.end_time and (old.status::text = any(active)) then return new; end if;   -- nothing relevant changed
  n_end := coalesce(new.end_time, new.start_time + interval '1 hour');
  if exists (select 1 from public.appointments a
             where a.id <> new.id and a.assigned_technician_id = new.assigned_technician_id and a.appointment_date = new.appointment_date and a.status::text = any(active)
               and a.start_time < n_end and coalesce(a.end_time, a.start_time + interval '1 hour') > new.start_time) then
    raise exception 'technician_conflict';
  end if;
  return new;
end $$;
drop trigger if exists trg_p3k_prevent_technician_overlap on public.appointments;
create trigger trg_p3k_prevent_technician_overlap before insert or update on public.appointments for each row execute function public.p3k_prevent_technician_overlap();

-- NOT included (needs your decision): a database check of business hours. The hours currently live in js/config.js and are enforced by the app;
-- copying them into SQL would create a second place to keep in sync. Tell me if you want it.
