-- GREEN GATOR — PHASE 3I: NOTIFICATIONS, REMINDERS, AUDIT LOG (PROPOSED; REVIEW BEFORE RUNNING; NOT RUN BY CLAUDE)
-- Run phase-3i-inspect.sql first. This file adapts to the REAL columns of `notifications` and `audit_logs` at run time
-- (it looks them up in information_schema) instead of assuming them, and a notification/audit failure NEVER blocks the main operation.
-- Verified relationships used: appointments.customer_id -> customers.id -> customers.profile_id -> profiles.id ;
--   appointments.assigned_technician_id -> technicians.id -> technicians.profile_id ; profiles.role in (customer, technician, admin, executive).
-- Safe to re-run: CREATE OR REPLACE / DROP IF EXISTS with unique names. No data is deleted, except UNREAD reminder notifications of an
-- appointment that was rescheduled or cancelled (they would be stale).
-- ONE additive schema change: notifications.dedupe_key (text, unique when set) so a retried event cannot create a second notification.

alter table public.notifications add column if not exists dedupe_key text;
create unique index if not exists notifications_dedupe_key_uidx on public.notifications (dedupe_key) where dedupe_key is not null;

-- ---------- helpers ----------
create or replace function public._pick_col(p_table text, p_candidates text[]) returns text
language sql stable set search_path = public, information_schema as $$
  select c from unnest(p_candidates) with ordinality t(c, o)
  where exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = p_table and column_name = c)
  order by o limit 1;
$$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'); $$;
create or replace function public.is_executive() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'executive'); $$;
create or replace function public.customer_profile_id(cust uuid) returns uuid language sql stable security definer set search_path = public as $$
  select profile_id from public.customers where id = cust; $$;
create or replace function public.technician_profile_id(tech uuid) returns uuid language sql stable security definer set search_path = public as $$
  select profile_id from public.technicians where id = tech; $$;
create or replace function public.admin_profile_ids() returns setof uuid language sql stable security definer set search_path = public as $$
  select id from public.profiles where role = 'admin'; $$;

-- ---------- the ONLY two ways a notification / audit row is written (never callable from the browser) ----------
create or replace function public.create_notification(p_user uuid, p_title text, p_message text, p_type text, p_rel_type text, p_rel_id uuid, p_link text, p_key text)
returns void language plpgsql security definer set search_path = public as $$
declare cu text; ct text; cm text; cty text; crt text; cri text; cl text; cols text[]; vals text[];
begin
  if p_user is null then return; end if;
  cu  := public._pick_col('notifications', array['user_id','recipient_id','profile_id']);
  ct  := public._pick_col('notifications', array['title','subject']);
  cm  := public._pick_col('notifications', array['message','body','content']);
  cty := public._pick_col('notifications', array['type','notification_type','category']);
  crt := public._pick_col('notifications', array['related_type','entity_type','reference_type']);
  cri := public._pick_col('notifications', array['related_id','entity_id','reference_id']);
  cl  := public._pick_col('notifications', array['link','url','action_url']);
  if cu is null or ct is null then raise warning 'create_notification: recipient/title columns not found on notifications'; return; end if;
  cols := array[quote_ident(cu), quote_ident(ct), 'dedupe_key']; vals := array[quote_literal(p_user::text), quote_literal(p_title), quote_nullable(p_key)];
  if cm  is not null then cols := cols || quote_ident(cm);  vals := vals || quote_nullable(p_message);       end if;
  if cty is not null then cols := cols || quote_ident(cty); vals := vals || quote_nullable(p_type);          end if;
  if crt is not null then cols := cols || quote_ident(crt); vals := vals || quote_nullable(p_rel_type);      end if;
  if cri is not null then cols := cols || quote_ident(cri); vals := vals || quote_nullable(p_rel_id::text);  end if;
  if cl  is not null then cols := cols || quote_ident(cl);  vals := vals || quote_nullable(p_link);          end if;
  execute format('insert into public.notifications (%s) values (%s) on conflict do nothing', array_to_string(cols, ', '), array_to_string(vals, ', '));   -- duplicate dedupe_key = silently ignored
exception when others then raise warning 'create_notification skipped: %', sqlerrm;
end $$;

create or replace function public.write_audit(p_action text, p_entity text, p_entity_id uuid, p_old jsonb, p_new jsonb, p_summary text)
returns void language plpgsql security definer set search_path = public as $$
declare ca text; cac text; ce text; cei text; cs text; co text; cn text; cols text[]; vals text[];
begin
  ca  := public._pick_col('audit_logs', array['actor_id','user_id','performed_by']);
  cac := public._pick_col('audit_logs', array['action','event','action_type']);
  ce  := public._pick_col('audit_logs', array['entity_type','table_name','record_type']);
  cei := public._pick_col('audit_logs', array['entity_id','record_id']);
  cs  := public._pick_col('audit_logs', array['summary','description']);
  co  := public._pick_col('audit_logs', array['old_values','old_data','previous_values']);
  cn  := public._pick_col('audit_logs', array['new_values','new_data']);
  if cac is null or ce is null then raise warning 'write_audit: action/entity columns not found on audit_logs'; return; end if;
  cols := array[quote_ident(cac), quote_ident(ce)]; vals := array[quote_literal(p_action), quote_literal(p_entity)];
  if ca  is not null then cols := cols || quote_ident(ca);  vals := vals || quote_nullable(auth.uid()::text); end if;   -- the actor comes from the JWT, never from the browser
  if cei is not null then cols := cols || quote_ident(cei); vals := vals || quote_nullable(p_entity_id::text); end if;
  if cs  is not null then cols := cols || quote_ident(cs);  vals := vals || quote_nullable(p_summary);         end if;
  if co  is not null then cols := cols || quote_ident(co);  vals := vals || quote_nullable(p_old::text);       end if;
  if cn  is not null then cols := cols || quote_ident(cn);  vals := vals || quote_nullable(p_new::text);       end if;
  execute format('insert into public.audit_logs (%s) values (%s)', array_to_string(cols, ', '), array_to_string(vals, ', '));
exception when others then raise warning 'write_audit skipped: %', sqlerrm;
end $$;

-- unread reminders for an appointment that changed (stale)
create or replace function public.p3i_clear_reminders(appt uuid) returns void language plpgsql security definer set search_path = public as $$
declare c_read text := public._pick_col('notifications', array['is_read','read']); c_at text := public._pick_col('notifications', array['read_at']); cond text := '';
begin
  if c_read is not null then cond := format(' and not coalesce(%I, false)', c_read); elsif c_at is not null then cond := format(' and %I is null', c_at); end if;
  execute format('delete from public.notifications where dedupe_key like %L%s', 'reminder%:' || appt || ':%', cond);
exception when others then raise warning 'p3i_clear_reminders skipped: %', sqlerrm;
end $$;

create or replace function public.p3i_label(s text) returns text language sql immutable as $$ select initcap(replace(coalesce(s, ''), '_', ' ')); $$;

-- ---------- appointments: booking / cancel / reschedule / assignment / status / completion ----------
create or replace function public.p3i_on_appointment() returns trigger language plpgsql security definer set search_path = public as $$
declare cp uuid; tn uuid; tp uuid; adm uuid; k text; d text; changed boolean;
begin
  cp := public.customer_profile_id(new.customer_id);
  k := 'appt:' || new.id || ':' || txid_current();                         -- same event inside one transaction can never notify twice
  d := coalesce(to_char(new.appointment_date, 'FMDay, FMMonth FMDD'), 'the scheduled date');
  if tg_op = 'INSERT' then
    perform public.write_audit('appointment_created', 'appointment', new.id, null,
      jsonb_build_object('status', new.status, 'appointment_date', new.appointment_date, 'start_time', new.start_time, 'assigned_technician_id', new.assigned_technician_id), 'Appointment created');
    perform public.create_notification(cp, 'Booking received', 'We received your appointment request for ' || d || '.', 'booking', 'appointment', new.id, null, k || ':created:c');
    for adm in select public.admin_profile_ids() loop
      perform public.create_notification(adm, case when new.assigned_technician_id is null then 'New appointment needs a technician' else 'New appointment' end,
        'An appointment was booked for ' || d || '.', 'booking', 'appointment', new.id, null, k || ':created:a:' || adm);
    end loop;
    if new.assigned_technician_id is not null then
      perform public.create_notification(public.technician_profile_id(new.assigned_technician_id), 'New job assigned', 'You have a job on ' || d || '.', 'assignment', 'appointment', new.id, null, k || ':assigned:t');
    end if;
    return new;
  end if;
  if new.status is distinct from old.status then
    perform public.write_audit('appointment_status_changed', 'appointment', new.id, jsonb_build_object('status', old.status), jsonb_build_object('status', new.status), 'Status: ' || old.status || ' to ' || new.status);
    tp := public.technician_profile_id(new.assigned_technician_id);
    if new.status::text = 'cancelled' then
      perform public.create_notification(cp, 'Appointment cancelled', 'Your appointment on ' || d || ' was cancelled.', 'cancellation', 'appointment', new.id, null, k || ':cancel:c');
      perform public.create_notification(tp, 'Job cancelled', 'The job on ' || d || ' was cancelled.', 'cancellation', 'appointment', new.id, null, k || ':cancel:t');
      for adm in select public.admin_profile_ids() loop perform public.create_notification(adm, 'Appointment cancelled', 'An appointment on ' || d || ' was cancelled.', 'cancellation', 'appointment', new.id, null, k || ':cancel:a:' || adm); end loop;
      perform public.p3i_clear_reminders(new.id);
    elsif new.status::text = 'confirmed' then
      perform public.create_notification(cp, 'Appointment confirmed', 'Your appointment on ' || d || ' is confirmed.', 'confirmation', 'appointment', new.id, null, k || ':confirm:c');
    elsif new.status::text = 'completed' then
      perform public.create_notification(cp, 'Service completed', 'Your service visit is complete. Thank you!', 'completion', 'appointment', new.id, null, k || ':done:c');
    elsif new.status::text = 'en_route' then
      perform public.create_notification(cp, 'Your technician is on the way', 'Your technician has started the trip to your address.', 'status', 'appointment', new.id, null, k || ':route:c');
    end if;
  end if;
  if new.appointment_date is distinct from old.appointment_date or new.start_time is distinct from old.start_time then
    perform public.write_audit('appointment_rescheduled', 'appointment', new.id,
      jsonb_build_object('appointment_date', old.appointment_date, 'start_time', old.start_time), jsonb_build_object('appointment_date', new.appointment_date, 'start_time', new.start_time), 'Rescheduled');
    perform public.create_notification(cp, 'Appointment rescheduled', 'Your appointment is now ' || d || '.', 'reschedule', 'appointment', new.id, null, k || ':resched:c');
    perform public.create_notification(public.technician_profile_id(new.assigned_technician_id), 'Job rescheduled', 'A job moved to ' || d || '.', 'reschedule', 'appointment', new.id, null, k || ':resched:t');
    for adm in select public.admin_profile_ids() loop perform public.create_notification(adm, 'Appointment rescheduled', 'An appointment moved to ' || d || '.', 'reschedule', 'appointment', new.id, null, k || ':resched:a:' || adm); end loop;
    perform public.p3i_clear_reminders(new.id);
  end if;
  if new.assigned_technician_id is distinct from old.assigned_technician_id then
    perform public.write_audit(case when old.assigned_technician_id is null then 'technician_assigned' else 'technician_reassigned' end, 'appointment', new.id,
      jsonb_build_object('assigned_technician_id', old.assigned_technician_id), jsonb_build_object('assigned_technician_id', new.assigned_technician_id), 'Technician changed');
    perform public.create_notification(public.technician_profile_id(new.assigned_technician_id), case when old.assigned_technician_id is null then 'New job assigned' else 'Job reassigned to you' end,
      'You have a job on ' || d || '.', 'assignment', 'appointment', new.id, null, k || ':assigned:t');
    if old.assigned_technician_id is not null then
      perform public.create_notification(public.technician_profile_id(old.assigned_technician_id), 'Job reassigned', 'A job on ' || d || ' was reassigned.', 'assignment', 'appointment', new.id, null, k || ':unassigned:t');
    end if;
  end if;
  return new;
exception when others then raise warning 'p3i_on_appointment skipped: %', sqlerrm; return new;
end $$;
drop trigger if exists trg_p3i_appointments on public.appointments;
create trigger trg_p3i_appointments after insert or update on public.appointments for each row execute function public.p3i_on_appointment();

-- ---------- emergency + callback requests (column access via jsonb, so a missing column cannot break writes) ----------
create or replace function public.p3i_on_request() returns trigger language plpgsql security definer set search_path = public as $$
declare n jsonb := to_jsonb(new); o jsonb := case when tg_op = 'UPDATE' then to_jsonb(old) end; kind text := case when tg_table_name = 'emergency_requests' then 'emergency' else 'callback' end;
        cp uuid; adm uuid; k text; ent text := kind || '_request';
begin
  cp := public.customer_profile_id((n->>'customer_id')::uuid);
  k := kind || ':' || new.id || ':' || txid_current();
  if tg_op = 'INSERT' then
    perform public.write_audit(kind || '_request_created', ent, new.id, null, jsonb_build_object('status', n->>'status'), initcap(kind) || ' request created');
    for adm in select public.admin_profile_ids() loop
      perform public.create_notification(adm, case when kind = 'emergency' then 'New emergency request' else 'New callback request' end, 'A customer sent ' || case when kind = 'emergency' then 'an emergency' else 'a callback' end || ' request that needs attention.', kind, ent, new.id, null, k || ':new:' || adm);
    end loop;
    return new;
  end if;
  if n->>'status' is distinct from o->>'status' then
    perform public.write_audit(kind || '_request_status_changed', ent, new.id, jsonb_build_object('status', o->>'status'), jsonb_build_object('status', n->>'status'), 'Status: ' || (o->>'status') || ' to ' || (n->>'status'));
    perform public.create_notification(cp, initcap(kind) || ' request update', 'Your ' || kind || ' request is now: ' || public.p3i_label(n->>'status') || '.', kind, ent, new.id, null, k || ':status:c');
  end if;
  if kind = 'emergency' and n->>'assigned_technician_id' is distinct from o->>'assigned_technician_id' and n->>'assigned_technician_id' is not null then
    perform public.write_audit('emergency_request_assigned', ent, new.id, jsonb_build_object('assigned_technician_id', o->>'assigned_technician_id'), jsonb_build_object('assigned_technician_id', n->>'assigned_technician_id'), 'Technician assigned');
    perform public.create_notification(public.technician_profile_id((n->>'assigned_technician_id')::uuid), 'Emergency job assigned', 'An emergency request was assigned to you.', 'assignment', ent, new.id, null, k || ':assigned:t');
  end if;
  return new;
exception when others then raise warning 'p3i_on_request skipped: %', sqlerrm; return new;
end $$;
drop trigger if exists trg_p3i_emergency on public.emergency_requests;
create trigger trg_p3i_emergency after insert or update on public.emergency_requests for each row execute function public.p3i_on_request();
drop trigger if exists trg_p3i_callback on public.callback_requests;
create trigger trg_p3i_callback after insert or update on public.callback_requests for each row execute function public.p3i_on_request();

-- ---------- reminders (in-app). Lead time + timezone are settings, not code ----------
create or replace function public.business_timezone() returns text language plpgsql stable security definer set search_path = public as $$
declare v text;
begin
  begin execute 'select trim(both ''"'' from value::text) from public.business_settings where key = ''timezone'' limit 1' into v; exception when others then v := null; end;
  if v is null or not exists (select 1 from pg_timezone_names where name = v) then v := 'America/Denver'; end if;
  return v;
end $$;
create or replace function public.reminder_lead_hours() returns int language plpgsql stable security definer set search_path = public as $$
declare v int;
begin
  begin execute 'select (trim(both ''"'' from value::text))::int from public.business_settings where key = ''reminder_hours_before'' limit 1' into v; exception when others then v := null; end;
  return coalesce(nullif(v, 0), 24);
end $$;

create or replace function public.generate_appointment_reminders(p_lead_hours int default null) returns int
language plpgsql security definer set search_path = public as $$
declare lead int := coalesce(p_lead_hours, public.reminder_lead_hours()); tz text := public.business_timezone(); r record; n int := 0;
begin
  for r in
    select a.id, a.customer_id, a.assigned_technician_id, a.appointment_date as d, a.start_time as t
    from public.appointments a
    where a.status::text in ('confirmed', 'assigned') and a.appointment_date is not null and a.start_time is not null
      and ((a.appointment_date + a.start_time) at time zone tz) >  now()
      and ((a.appointment_date + a.start_time) at time zone tz) <= now() + make_interval(hours => lead)
  loop
    -- the key contains the CURRENT date+time, so a rescheduled appointment gets a fresh reminder and an old one is never re-sent
    perform public.create_notification(public.customer_profile_id(r.customer_id), 'Appointment reminder',
      format('Your pest control visit is on %s at %s.', to_char(r.d, 'FMDay, FMMonth FMDD'), to_char(r.t, 'FMHH12:MI AM')), 'reminder', 'appointment', r.id, null, format('reminder:%s:%s:%s', r.id, r.d, r.t));
    if r.assigned_technician_id is not null then
      perform public.create_notification(public.technician_profile_id(r.assigned_technician_id), 'Upcoming job',
        format('You have a job on %s at %s.', to_char(r.d, 'FMDay, FMMonth FMDD'), to_char(r.t, 'FMHH12:MI AM')), 'reminder', 'appointment', r.id, null, format('reminder-tech:%s:%s:%s', r.id, r.d, r.t));
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------- security ----------
revoke all on function public.create_notification(uuid, text, text, text, text, uuid, text, text) from public, anon, authenticated;   -- no forging from the browser
revoke all on function public.write_audit(text, text, uuid, jsonb, jsonb, text) from public, anon, authenticated;
revoke all on function public.generate_appointment_reminders(int) from public, anon, authenticated;
revoke all on function public.p3i_clear_reminders(uuid) from public, anon, authenticated;
revoke all on function public.customer_profile_id(uuid), public.technician_profile_id(uuid), public.admin_profile_ids() from public, anon, authenticated;

alter table public.notifications enable row level security;
alter table public.audit_logs    enable row level security;

do $$
declare c text := public._pick_col('notifications', array['user_id','recipient_id','profile_id']);
begin
  if c is null then raise notice 'notifications recipient column not found: add the select/update policies manually'; return; end if;
  execute 'drop policy if exists p3i_notif_select on public.notifications';
  execute format('create policy p3i_notif_select on public.notifications for select to authenticated using (%I = auth.uid())', c);
  execute 'drop policy if exists p3i_notif_update on public.notifications';
  execute format('create policy p3i_notif_update on public.notifications for update to authenticated using (%I = auth.uid()) with check (%I = auth.uid())', c, c);
end $$;
revoke insert, delete on public.notifications from anon, authenticated;

-- a user may change ONLY the read flag of their own notification
create or replace function public.p3i_notif_guard() returns trigger language plpgsql as $$
declare keep text[] := array_remove(array[public._pick_col('notifications', array['is_read','read']), public._pick_col('notifications', array['read_at'])], null);
begin
  if auth.uid() is null or coalesce(array_length(keep, 1), 0) = 0 then return new; end if;
  if (to_jsonb(new) - keep) is distinct from (to_jsonb(old) - keep) then raise exception 'Only the read status of a notification can be changed'; end if;
  return new;
end $$;
drop trigger if exists trg_p3i_notif_guard on public.notifications;
create trigger trg_p3i_notif_guard before update on public.notifications for each row execute function public.p3i_notif_guard();

drop policy if exists p3i_audit_select on public.audit_logs;
create policy p3i_audit_select on public.audit_logs for select to authenticated using (public.is_admin() or public.is_executive());
revoke insert, update, delete on public.audit_logs from anon, authenticated;       -- written only by the trusted functions above
create or replace function public.p3i_audit_append_only() returns trigger language plpgsql as $$ begin raise exception 'audit_logs is append-only'; end $$;
drop trigger if exists trg_p3i_audit_append_only on public.audit_logs;
create trigger trg_p3i_audit_append_only before update or delete on public.audit_logs for each row execute function public.p3i_audit_append_only();

-- ---------- scheduling (Supabase dashboard, not this script) ----------
-- 1) Database > Extensions: enable pg_cron.   2) Then run once:
--   select cron.schedule('gg-appointment-reminders', '*/15 * * * *', $$select public.generate_appointment_reminders()$$);
-- Change the lead time without code: insert/update business_settings (key 'reminder_hours_before', value 24); timezone: key 'timezone'.
-- Email/SMS are NOT part of this script: no provider is configured. See the notes delivered with this phase.
