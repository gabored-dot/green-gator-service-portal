-- GREEN GATOR — PHASE 3I: READ-ONLY INSPECTION. Changes nothing.
-- Run in the Supabase SQL Editor and send me the single JSON result.
select jsonb_pretty(jsonb_build_object(
  'columns', (select jsonb_agg(jsonb_build_object('table', table_name, 'column', column_name, 'type', data_type, 'udt', udt_name, 'nullable', is_nullable, 'default', column_default) order by table_name, ordinal_position)
              from information_schema.columns where table_schema = 'public' and table_name in ('notifications','audit_logs','business_settings')),
  'constraints', (select jsonb_agg(jsonb_build_object('table', conrelid::regclass::text, 'name', conname, 'definition', pg_get_constraintdef(oid)))
                  from pg_constraint where conrelid::regclass::text in ('notifications','audit_logs','business_settings')),
  'enums', (select jsonb_agg(jsonb_build_object('enum', t.typname, 'values', (select jsonb_agg(e.enumlabel order by e.enumsortorder) from pg_enum e where e.enumtypid = t.oid)))
            from pg_type t where t.typtype = 'e' and t.typnamespace = 'public'::regnamespace),
  'rls', (select jsonb_agg(jsonb_build_object('table', relname, 'rls', relrowsecurity)) from pg_class where relnamespace = 'public'::regnamespace and relname in ('notifications','audit_logs','business_settings')),
  'policies', (select jsonb_agg(jsonb_build_object('table', tablename, 'policy', policyname, 'cmd', cmd, 'roles', roles, 'using', qual, 'check', with_check)) from pg_policies where schemaname = 'public' and tablename in ('notifications','audit_logs','business_settings')),
  'grants', (select jsonb_agg(jsonb_build_object('table', table_name, 'grantee', grantee, 'privilege', privilege_type)) from information_schema.role_table_grants where table_schema = 'public' and table_name in ('notifications','audit_logs') and grantee in ('anon','authenticated')),
  'triggers', (select jsonb_agg(jsonb_build_object('table', event_object_table, 'trigger', trigger_name, 'event', event_manipulation, 'action', action_statement))
               from information_schema.triggers where trigger_schema = 'public' and event_object_table in ('appointments','emergency_requests','callback_requests','notifications','audit_logs')),
  'functions', (select jsonb_agg(jsonb_build_object('name', p.proname, 'args', pg_get_function_identity_arguments(p.oid), 'security_definer', p.prosecdef))
                from pg_proc p where p.pronamespace = 'public'::regnamespace and (p.proname ilike '%notif%' or p.proname ilike '%audit%' or p.proname ilike '%remind%')),
  'extensions', (select jsonb_agg(extname) from pg_extension where extname in ('pg_cron','pg_net','pgcrypto')),
  'settings_rows', (select jsonb_agg(to_jsonb(b)) from (select * from public.business_settings limit 25) b),
  'counts', jsonb_build_object('notifications', case when to_regclass('public.notifications') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.notifications', false, true, '')))[1]::text end, 'audit_logs', case when to_regclass('public.audit_logs') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.audit_logs', false, true, '')))[1]::text end)
)) as inspection;
