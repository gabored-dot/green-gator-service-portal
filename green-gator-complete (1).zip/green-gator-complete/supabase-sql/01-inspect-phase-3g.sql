-- GREEN GATOR — PHASE 3G: READ-ONLY INSPECTION. Changes nothing.
-- Run this once in the Supabase SQL Editor and send me the single JSON result.
-- It reports the real columns, constraints, enum values, policies, functions, triggers and bucket settings I could not see.
select jsonb_pretty(jsonb_build_object(
  'columns', (select jsonb_agg(jsonb_build_object('table', table_name, 'column', column_name, 'type', data_type, 'udt', udt_name, 'nullable', is_nullable, 'default', column_default) order by table_name, ordinal_position)
              from information_schema.columns
              where table_schema = 'public' and table_name in ('job_media','job_notes','job_signatures','service_jobs','service_reports','appointments','technicians')),
  'foreign_keys', (select jsonb_agg(jsonb_build_object('table', conrelid::regclass::text, 'constraint', conname, 'definition', pg_get_constraintdef(oid)))
                   from pg_constraint where contype in ('f','u','c') and conrelid::regclass::text in ('job_media','job_notes','job_signatures','service_jobs','appointments')),
  'enums', (select jsonb_agg(jsonb_build_object('enum', t.typname, 'values', (select jsonb_agg(e.enumlabel order by e.enumsortorder) from pg_enum e where e.enumtypid = t.oid)))
            from pg_type t where t.typtype = 'e' and t.typnamespace = 'public'::regnamespace),
  'rls_enabled', (select jsonb_agg(jsonb_build_object('table', relname, 'rls', relrowsecurity))
                  from pg_class where relnamespace = 'public'::regnamespace and relname in ('job_media','job_notes','job_signatures','service_jobs','appointments','technicians')),
  'policies', (select jsonb_agg(jsonb_build_object('schema', schemaname, 'table', tablename, 'policy', policyname, 'cmd', cmd, 'roles', roles, 'using', qual, 'check', with_check))
               from pg_policies where (schemaname = 'public' and tablename in ('job_media','job_notes','job_signatures','service_jobs','appointments','technicians','customers','profiles'))
                                   or (schemaname = 'storage' and tablename = 'objects')),
  'functions', (select jsonb_agg(jsonb_build_object('name', p.proname, 'args', pg_get_function_identity_arguments(p.oid), 'security_definer', p.prosecdef))
                from pg_proc p where p.pronamespace = 'public'::regnamespace and (p.proname ilike '%complete%' or p.proname ilike '%job%' or p.proname ilike '%technician%' or p.proname ilike '%is_admin%')),
  'triggers', (select jsonb_agg(jsonb_build_object('table', event_object_table, 'trigger', trigger_name, 'event', event_manipulation))
               from information_schema.triggers where trigger_schema = 'public' and event_object_table in ('appointments','service_jobs','job_media','job_notes','job_signatures')),
  'buckets', (select jsonb_agg(jsonb_build_object('id', id, 'public', public, 'file_size_limit', file_size_limit, 'allowed_mime_types', allowed_mime_types)) from storage.buckets),
  'row_counts', jsonb_build_object('job_media', case when to_regclass('public.job_media') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.job_media', false, true, '')))[1]::text end, 'job_notes', case when to_regclass('public.job_notes') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.job_notes', false, true, '')))[1]::text end, 'job_signatures', case when to_regclass('public.job_signatures') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.job_signatures', false, true, '')))[1]::text end, 'service_jobs', case when to_regclass('public.service_jobs') is null then 'table does not exist' else (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.service_jobs', false, true, '')))[1]::text end)
)) as inspection;
