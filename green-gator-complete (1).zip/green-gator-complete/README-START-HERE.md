# Green Gator Service Portal: complete package

```
website/        The deployable site (index.html, css/, js/). Upload THIS folder's contents to GitHub Pages.
supabase-sql/   Every SQL file, numbered in the order to use them.
docs/           Setup notes (reminders, notifications, email/SMS).
```

## SQL: order and what each file does
| # | File | Type | When |
|---|---|---|---|
| 00 | `00-inspect-other-tables.sql` | read-only | Now. Send me the result. |
| 01 | `01-inspect-phase-3g.sql` | read-only | Now. Send me the JSON result. |
| 02 | `02-inspect-phase-3i.sql` | read-only | Now. Send me the JSON result. |
| 03 | `03-run-phase-3f-technician-policies.sql` | changes the database | After I review 00 to 02 with you |
| 04 | `04-run-phase-3g-migration.sql` | changes the database | After 03 (it updates the guard created in 03) |
| 05 | `05-run-phase-3i-migration.sql` | changes the database | After 04 |
| 06 | `06-run-admin-scheduling.sql` | changes the database | After 05. Needed for the admin Appointments page, Calendar and technician assignment on live data. Tested in a local PostgreSQL. |

**Update:** your inspection run showed that `job_notes` (and `job_signatures`) do not exist in your database. File 04 now creates them only if missing, and file 01 reports "table does not exist" instead of failing. Re-run 01 and 04 from this package.

Files 00 to 02 never change anything. Files 03 to 06 are safe to re-run, delete no data, and keep RLS on. Do not run 03 to 06 until the inspection results have been checked.

## Deploy the website
1. Put the contents of `website/` in your GitHub repo (replace the old files, keep the same folder layout: `index.html`, `css/styles.css`, `js/*.js`).
2. Do not put any `.sql` file or key other than the anon key in that repo.
3. Test locally first with VS Code "Live Server" opened on the `website` folder.

## Supabase dashboard tasks
- Authentication > URL Configuration: Site URL and a Redirect URL = `https://gabored-dot.github.io/green-gator-service-portal/`
- Decide whether "Confirm email" stays on.
- Storage: private bucket named `job-media`; tell me its allowed file types.
- Database > Extensions: enable `pg_cron`, then add the reminder schedule in `docs/phase-3i-reminders-and-notifications.md`.

## Test accounts to create
2 customers, 2 technicians (profiles.role = technician plus a `technicians` row linked by profile_id), 1 admin (profiles.role = admin). Public signup only makes customers.

## What is built and what is not
Start with `DEMO-GUIDE.md` if you are preparing a client demo.

Live-capable: sign in/up, password reset, customer profile, booking, cancel/reschedule, emergency and callback requests, technician jobs and status, job notes/photos/signature/completion, notifications, reminders, audit log (admin read-only), admin appointments + calendar + technician assignment (after SQL 06), owner overview with real counts.
Not built: email/SMS, revenue/billing reports, technician availability schedules, editing booking rules from the portal. Admin and owner screens show demo data only in Demo mode (clearly labelled).

## When something fails
Open the browser console (F12) and copy any red lines tagged `[db]`, `[booking]`, `[appt]`, `[request]`, `[jobs]`, `[media]`, `[notif]`. Signed in, run `API.diagnoseAuth()` and `API.diagnoseData()` in the console and send me the tables they print (no tokens are shown).
