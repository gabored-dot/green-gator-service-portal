# Client demo guide

## Before the demo (15 minutes)
1. Deploy `website/` and open the live URL in a private window.
2. Run `supabase-sql/03` to `06` ONLY after the inspection results were checked (see README-START-HERE).
3. Create demo accounts with FICTIONAL names: 1 customer, 1 technician, 1 admin, 1 owner. Add a few fictional appointments through the booking screen so the calendar is not empty.
4. Click through the flow once yourself. Keep the browser console closed during the demo.

## Safest things to show (in this order)
1. **Customer:** sign-in, book a service (3-day window, business hours, Sunday closed), see it on the dashboard, appointment history.
2. **Technician (phone view):** today's jobs, tap-to-call, status buttons with confirmation, notes, photo, customer signature, completion.
3. **Admin:** Operations overview, Appointments search and filters, Calendar (month, week, day), edit a time (try a conflict to show the checks), assign a technician.
4. **Owner:** Overview with real counts (note: revenue says "Not available"), technician workload, read-only calendar.
5. **Notifications bell** and the Audit log (admin).

## Say clearly, do not hide
- Email and SMS messages are planned, not built. Reminders appear inside the portal only.
- Revenue and billing reports are planned.
- "Demo mode" (the demo login buttons) uses fictional sample data and saves nothing. The banner says so.
- Anything on the **Feature status** page marked Partial is built but still being verified on the live database.

## Avoid in a live demo
- Do not demo emergency job completion (no database rule behind it yet).
- Do not promise that technician availability schedules exist: conflicts are checked against appointments only.
- Do not edit booking rules on screen: they are shown read-only on purpose.
