# Phase 3I — setup and manual test notes

## What is automatic vs what you must enable
| Feature | Where it runs | Status |
|---|---|---|
| In-app notifications (booking, cancel, reschedule, assignment, completion, emergency/callback updates) | Database triggers (`phase-3i-migration.sql`) | Works as soon as the migration is applied |
| Audit log | Same triggers; actor = `auth.uid()` from the JWT | Same |
| Appointment reminders (in-app) | `generate_appointment_reminders()` run by **pg_cron** | You must enable pg_cron and add the schedule (below) |
| Email / SMS | Not built: **no provider is configured** | Needs a provider decision (below). Nothing is sent and the app never claims it was |

GitHub Pages cannot run background jobs, so reminders run inside Supabase.

## Enable reminders
1. Supabase Dashboard > Database > Extensions > enable `pg_cron`.
2. SQL Editor, run once:
   `select cron.schedule('gg-appointment-reminders', '*/15 * * * *', $$select public.generate_appointment_reminders()$$);`
3. Optional settings (rows in `business_settings`, no code change): key `reminder_hours_before` (default 24), key `timezone` (default America/Denver). Check the real shape of that table with `phase-3i-inspect.sql` first.
A reminder is skipped for cancelled/completed appointments, is not repeated (its key includes the date and time), and a rescheduled appointment gets a fresh one; unread reminders for the old time are removed.

## Adding email or SMS later (not done)
Choose a provider (for example Resend or Postmark for email, Twilio for SMS). Put its API key ONLY in Supabase Edge Function secrets
(`supabase secrets set PROVIDER_API_KEY=...`), never in this repo or in browser files. A server-side Edge Function would read new rows from
`notifications`, send them, and record `sent` or `failed`; booking must never wait on it. The `notifications` table already is the single
source of events, so no frontend change is needed.

## Manual tests (after running the migration)
1. Customer books: customer sees "Booking received"; admin sees "New appointment needs a technician"; `audit_logs` has `appointment_created` with the customer's id as actor.
2. Admin assigns a technician (Table Editor or SQL while impersonating): that technician sees "New job assigned".
3. Customer cancels or reschedules: customer, technician and admin notifications appear once; reminders for the old time disappear.
4. Mark a notification read, refresh: it stays read. Sign in as another customer: they never see it.
5. As a customer in the browser console: `await supabase.rpc('create_notification', {...})` and a direct insert into `audit_logs` must fail with permission denied.
6. Audit page: visible to admin only; no edit or delete controls; an SQL update/delete on `audit_logs` is rejected.
